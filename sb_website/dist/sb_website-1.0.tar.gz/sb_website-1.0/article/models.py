from django.db import models

# Create your models here.

# TODO: change to correct Model
class Default(models.Model):
    pass