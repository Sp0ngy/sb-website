from distutils.core import setup

setup(name='sb_website',
      version='1.0',
      description='Fick Scheiße',
      author='Ginstoff',
      author_email='gward@python.net',
      packages=['sb_website', 'home', 'article'],

)